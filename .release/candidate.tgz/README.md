# ERS Flutter client

This package integrates the framework-neutral ERS realtime client with Flutter application
lifecycle signals. It provides session-scoped client ownership, optional connectivity hints,
and wall-clock and timer scheduler adapters.

```dart
import 'package:egensolve_realtime/lifecycle.dart';
import 'package:egensolve_realtime_flutter/egensolve_realtime_flutter.dart';

final owner = FlutterRealtimeClientOwner(
  clientFactory: (signals) => RealtimeLifecycleClient(
    bootstrap: bootstrap,
    transport: transport,
    authCallback: authCallback,
    clock: const SystemClock(),
    scheduler: const TimerScheduler(),
    recoveryCoordinator: recoveryCoordinator,
    signals: signals,
  ),
);

owner.start();
```

Create one owner per authenticated application session. Dispose it at session end. Connectivity
signals are hints only; they never replace a real transport attempt.

## License

MIT. See [LICENSE](LICENSE).
