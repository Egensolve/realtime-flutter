# ERS Flutter client

This package integrates the framework-neutral ERS realtime client with Flutter application
lifecycle signals. It provides session-scoped client ownership, optional connectivity hints,
and wall-clock and timer scheduler adapters.

```dart
import 'package:egensolve_realtime/lifecycle.dart';
import 'package:egensolve_realtime_flutter/egensolve_realtime_flutter.dart';

final owner = FlutterRealtimeClientOwner(
  clientFactory: (signals) => RealtimeLifecycleClient(
    bootstrap: bootstrap,
    transport: transport,
    authCallback: authCallback,
    clock: const SystemClock(),
    scheduler: const TimerScheduler(),
    recoveryCoordinator: recoveryCoordinator,
    signals: signals,
  ),
);

owner.start();
```

Create one owner per authenticated application session. Dispose it at session end. Connectivity
signals are hints only; they never replace a real transport attempt.

## Calls platform boundary

`FlutterCallCoordinator` applies the framework-neutral Dart Calls state machine and dispatches its
ordered effects to injected canonical snapshot/credential, RTC session, CallKit/Android call
surface, and Android foreground-service ports. Push and socket invitations use the same
deduplicating path. Products choose the platform/provider plugins; this package exposes no
provider room, participant token, or SDK object. Logout and disposal stop media, discard
credentials and media keys, stop the foreground service, and end the OS call.

`ErsCallSurface` is the optional customizable UI foundation. It accepts the same `CallProjection`,
typed callbacks, custom media/participant/caption builders, and ambient Open UI Kit tokens; no RTC
provider objects cross the widget boundary.

## License

MIT. See [LICENSE](LICENSE).

## Intelligence package candidate

This is an unreleased candidate. Machine credentials remain on trusted backends. Content uses
private Media, control requests contain references only, and generated text is untrusted.
Profile/job polling, deadlines, cancellation, output expiry and applying results remain caller-owned.

This lifecycle adapter consumes the matching Dart candidate. Flutter apps request candidates through their own authenticated product backend; no machine credential is embedded in the app.
