# Changelog

## 0.3.0

- License this public package under MIT.
- Follow the hosted core client 0.3 release while retaining the existing Flutter adapter surface.
- Machine-credential APIs are for trusted backends, not Flutter applications.

## 0.2.1

- Provide Flutter app-lifecycle and connectivity-signal integration.
- Provide session-scoped lifecycle client ownership.
- Provide wall-clock and timer scheduler adapters.
- Limit the archive to the documented consumer-facing adapter surface.
