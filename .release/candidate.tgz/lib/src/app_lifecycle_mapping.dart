


library;

import 'package:egensolve_realtime/lifecycle.dart';
import 'package:flutter/widgets.dart' show AppLifecycleState;















LifecycleSignalKind? mapAppLifecycleState(AppLifecycleState state) {
  switch (state) {
    case AppLifecycleState.resumed:
      return LifecycleSignalKind.appForeground;
    case AppLifecycleState.inactive:
      return null;
    case AppLifecycleState.hidden:
    case AppLifecycleState.paused:
    case AppLifecycleState.detached:
      return LifecycleSignalKind.appBackground;
  }
}
