










library;



abstract interface class ConnectivitySignalSource {
  void Function() subscribe(void Function(bool isOnline) listener);
}
