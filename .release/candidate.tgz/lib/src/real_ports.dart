




library;

import 'dart:async';

import 'package:egensolve_realtime/lifecycle.dart';

final class SystemClock implements ClockPort {
  const SystemClock();

  @override
  int now() => DateTime.now().millisecondsSinceEpoch;
}

final class _TimerSchedulerHandle implements SchedulerHandle {
  _TimerSchedulerHandle(this.timer);

  final Timer timer;
}

final class TimerScheduler implements SchedulerPort {
  const TimerScheduler();

  @override
  SchedulerHandle schedule(int delayMs, void Function() callback) {
    return _TimerSchedulerHandle(
      Timer(Duration(milliseconds: delayMs), callback),
    );
  }

  @override
  void cancel(SchedulerHandle handle) {
    (handle as _TimerSchedulerHandle).timer.cancel();
  }
}
