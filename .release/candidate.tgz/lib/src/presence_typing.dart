






library;

import 'package:egensolve_realtime/lifecycle.dart';
import 'package:flutter/foundation.dart';

import 'real_ports.dart';




final class PresenceMembersNotifier
    extends ValueNotifier<Map<String, PresenceMember>> {
  PresenceMembersNotifier(this._client) : super(_client.presenceSnapshot) {
    _unsubscribe = _client.onPresenceEvent(_handle);
  }

  final RealtimeLifecycleClient _client;
  late final void Function() _unsubscribe;

  void _handle(PresenceEvent event) {
    value = _client.presenceSnapshot;
  }

  @override
  void dispose() {
    _unsubscribe();
    super.dispose();
  }
}





final class TypingActorsNotifier extends ValueNotifier<Set<String>> {
  TypingActorsNotifier(
    RealtimeLifecycleClient client, {
    ClockPort clock = const SystemClock(),
    SchedulerPort scheduler = const TimerScheduler(),
  }) : super(const {}) {
    _tracker = TypingIndicatorTracker(
      client: client,
      clock: clock,
      scheduler: scheduler,
      onChange: (actors) => value = actors,
    );
  }

  late final TypingIndicatorTracker _tracker;

  @override
  void dispose() {
    _tracker.dispose();
    super.dispose();
  }
}
