


library;

import 'package:egensolve_realtime/lifecycle.dart';
import 'package:flutter/widgets.dart' show AppLifecycleListener;

import 'app_lifecycle_mapping.dart';
import 'connectivity.dart';













typedef RealtimeLifecycleClientFactory = RealtimeLifecycleClient Function(
    LifecycleSignalSource signals);













































final class FlutterRealtimeClientOwner implements LifecycleSignalSource {
  FlutterRealtimeClientOwner({
    required RealtimeLifecycleClientFactory clientFactory,
    ConnectivitySignalSource? connectivity,
  })  : _clientFactory = clientFactory,
        _connectivity = connectivity;

  final RealtimeLifecycleClientFactory _clientFactory;
  final ConnectivitySignalSource? _connectivity;

  RealtimeLifecycleClient? _client;
  bool _terminated = false;
  bool _subscribed = false;

  void Function(LifecycleSignal signal)? _coreListener;
  AppLifecycleListener? _appLifecycleListener;
  void Function()? _connectivityUnsubscribe;

  
  
  RealtimeLifecycleClient? get client => _client;

  
  
  bool get isDisposed => _terminated;

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  void start() {
    if (_terminated) {
      throw StateError(
          'FlutterRealtimeClientOwner.start() called after endSession()/dispose() -- construct a new FlutterRealtimeClientOwner for a new session.');
    }
    final existing = _client;
    if (existing != null) {
      existing.start();
      return;
    }
    RealtimeLifecycleClient client;
    try {
      
      
      
      
      client = _clientFactory(this);
    } catch (_) {
      if (_subscribed) _disposeSignalSources();
      rethrow;
    }
    if (!_subscribed) {
      throw StateError(
          "FlutterRealtimeClientOwner.start(): the supplied clientFactory did not call "
          "signals.subscribe(...) -- pass signals: signals to RealtimeLifecycleClient(...) "
          "inside the factory so this owner's Flutter app-lifecycle/connectivity integration is "
          "actually wired in, instead of silently running with none.");
    }
    _client = client;
    client.start();
  }

  
  
  
  
  
  
  
  
  
  
  @override
  void Function() subscribe(void Function(LifecycleSignal signal) listener) {
    if (_terminated) {
      return () {};
    }
    if (_subscribed) {
      throw StateError(
          'FlutterRealtimeClientOwner.subscribe() called more than once -- this owner accepts '
          'exactly one core subscriber. This should never happen through the documented '
          'start() -> clientFactory(signals) -> RealtimeLifecycleClient(signals: signals) path; '
          'if you see this, something outside that path is calling subscribe() directly against '
          'a signal source that already has a subscriber.');
    }
    _subscribed = true;
    _coreListener = listener;
    _appLifecycleListener = AppLifecycleListener(
      onStateChange: (state) {
        
        
        
        
        if (_terminated) return;
        final kind = mapAppLifecycleState(state);
        if (kind != null) _coreListener?.call(LifecycleSignal(kind));
      },
    );
    _connectivityUnsubscribe = _connectivity?.subscribe((isOnline) {
      if (_terminated) return;
      _coreListener?.call(
        LifecycleSignal(
          isOnline
              ? LifecycleSignalKind.networkOnline
              : LifecycleSignalKind.networkOffline,
        ),
      );
    });
    return _disposeSignalSources;
  }

  void _disposeSignalSources() {
    _appLifecycleListener?.dispose();
    _appLifecycleListener = null;
    _connectivityUnsubscribe?.call();
    _connectivityUnsubscribe = null;
    _coreListener = null;
    _subscribed = false;
  }

  
  
  
  
  void stop() {
    _client?.stop();
  }

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  void endSession() {
    if (_terminated) return;
    _client?.resetForSessionChange();
    _terminate();
  }

  
  
  
  
  
  
  
  
  void dispose() {
    if (_terminated) return;
    _client?.stop();
    _terminate();
  }

  void _terminate() {
    _terminated = true;
    _client = null;
    _disposeSignalSources();
  }
}
