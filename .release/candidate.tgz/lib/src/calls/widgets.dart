







import 'package:egensolve_realtime/calls.dart';
import 'package:flutter/widgets.dart';
import 'package:open_ui_kit/open_ui_kit.dart';

typedef ErsCallContentBuilder = Widget Function(
    BuildContext context, CallProjection projection);

final class ErsCallSurface extends StatelessWidget {
  const ErsCallSurface({
    required this.projection,
    super.key,
    this.displayName = 'Call participant',
    this.elapsedLabel,
    this.mediaBuilder,
    this.participantsBuilder,
    this.captionsBuilder,
    this.onAccept,
    this.onDecline,
    this.onCancel,
    this.onEnd,
    this.onToggleMicrophone,
    this.onToggleCamera,
    this.onToggleScreenShare,
    this.onToggleCaptions,
    this.onRequestRecording,
    this.microphoneMuted = false,
    this.cameraOff = false,
    this.screenSharing = false,
    this.captionsEnabled,
  });

  final CallProjection projection;
  final String displayName;
  final String? elapsedLabel;
  final ErsCallContentBuilder? mediaBuilder;
  final ErsCallContentBuilder? participantsBuilder;
  final ErsCallContentBuilder? captionsBuilder;
  final VoidCallback? onAccept;
  final VoidCallback? onDecline;
  final VoidCallback? onCancel;
  final VoidCallback? onEnd;
  final VoidCallback? onToggleMicrophone;
  final VoidCallback? onToggleCamera;
  final VoidCallback? onToggleScreenShare;
  final VoidCallback? onToggleCaptions;
  final VoidCallback? onRequestRecording;
  final bool microphoneMuted;
  final bool cameraOff;
  final bool screenSharing;
  final bool? captionsEnabled;

  @override
  Widget build(BuildContext context) {
    final calls = UiThemeTokens.of(context);
    final reduceMotion = MediaQuery.disableAnimationsOf(context);
    final stage = _CallStage(
      projection: projection,
      calls: calls,
      displayName: displayName,
      mediaBuilder: mediaBuilder,
    );
    final rail = _CueRail(
      projection: projection,
      calls: calls,
      elapsedLabel: elapsedLabel,
      participantsBuilder: participantsBuilder,
      captionsBuilder: captionsBuilder,
      onAccept: onAccept,
      onDecline: onDecline,
      onCancel: onCancel,
      onEnd: onEnd,
      onToggleMicrophone: onToggleMicrophone,
      onToggleCamera: onToggleCamera,
      onToggleScreenShare: onToggleScreenShare,
      onToggleCaptions: onToggleCaptions,
      onRequestRecording: onRequestRecording,
      microphoneMuted: microphoneMuted,
      cameraOff: cameraOff,
      screenSharing: screenSharing,
      captionsEnabled: captionsEnabled ??
          const {
            CallCaptionsState.starting,
            CallCaptionsState.active,
            CallCaptionsState.stopping,
          }.contains(projection.captionsState),
      reduceMotion: reduceMotion,
    );
    return Semantics(
      container: true,
      label: 'Call controls',
      child: UiBox(
        background: calls.colors.background,
        child: UiSafeViewport(
          child: Padding(
            padding: EdgeInsets.all(calls.spacing.x3),
            child: LayoutBuilder(
              builder: (context, constraints) => constraints.maxWidth >= 760
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(child: stage),
                        SizedBox(width: calls.spacing.x3),
                        SizedBox(width: 280, child: rail),
                      ],
                    )
                  : SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          stage,
                          SizedBox(height: calls.spacing.x3),
                          rail
                        ],
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

final class _CallStage extends StatelessWidget {
  const _CallStage(
      {required this.projection,
      required this.calls,
      required this.displayName,
      this.mediaBuilder});
  final CallProjection projection;
  final UiThemeTokens calls;
  final String displayName;
  final ErsCallContentBuilder? mediaBuilder;

  @override
  Widget build(BuildContext context) {
    
    
    final stageTokens = calls.brightness == Brightness.dark
        ? calls.copyWith(
            colors: calls.colors.copyWith(
              surfaceInverse: calls.colors.background,
              textInverse: calls.colors.textPrimary,
            ),
          )
        : calls;
    return UiTheme(
      tokens: stageTokens,
      child: Builder(
          builder: (context) => ConstrainedBox(
                constraints: const BoxConstraints(minHeight: 240),
                child: UiBox(
                  background: stageTokens.colors.surfaceInverse,
                  borderRadius: calls.radius.xlAll,
                  clipBehavior: Clip.antiAlias,
                  child: mediaBuilder?.call(context, projection) ??
                      Center(
                        child: Padding(
                          padding: EdgeInsets.all(calls.spacing.x6),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              UiText(
                                displayName,
                                variant: UiTextVariant.heading,
                                tone: UiTextTone.inverse,
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: calls.spacing.x2),
                              UiText(
                                _statusLabel(projection.uiState),
                                variant: UiTextVariant.bodySm,
                                tone: UiTextTone.inverse,
                              ),
                            ],
                          ),
                        ),
                      ),
                ),
              )),
    );
  }
}

final class _CueRail extends StatelessWidget {
  const _CueRail({
    required this.projection,
    required this.calls,
    required this.reduceMotion,
    required this.microphoneMuted,
    required this.cameraOff,
    required this.screenSharing,
    required this.captionsEnabled,
    this.elapsedLabel,
    this.participantsBuilder,
    this.captionsBuilder,
    this.onAccept,
    this.onDecline,
    this.onCancel,
    this.onEnd,
    this.onToggleMicrophone,
    this.onToggleCamera,
    this.onToggleScreenShare,
    this.onToggleCaptions,
    this.onRequestRecording,
  });
  final CallProjection projection;
  final UiThemeTokens calls;
  final bool reduceMotion;
  final String? elapsedLabel;
  final ErsCallContentBuilder? participantsBuilder;
  final ErsCallContentBuilder? captionsBuilder;
  final VoidCallback? onAccept, onDecline, onCancel, onEnd;
  final VoidCallback? onToggleMicrophone, onToggleCamera;
  final VoidCallback? onToggleScreenShare, onToggleCaptions;
  final VoidCallback? onRequestRecording;
  final bool microphoneMuted, cameraOff, screenSharing, captionsEnabled;

  @override
  Widget build(BuildContext context) {
    final terminal = _terminal(projection.uiState);
    final incompatibleRecording =
        projection.processingProfile == CallProcessingProfile.e2eePrivate &&
            const {
              CallRecordingState.requested,
              CallRecordingState.starting,
              CallRecordingState.recording,
              CallRecordingState.finalizing,
            }.contains(projection.recordingState);
    final recording =
        projection.processingProfile == CallProcessingProfile.recordable &&
            const {
              CallRecordingState.starting,
              CallRecordingState.recording,
              CallRecordingState.finalizing,
            }.contains(projection.recordingState);
    final primaryControls = !terminal && projection.uiState != CallUiState.idle
        ? _primaryControls()
        : const <Widget>[];
    final content = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Semantics(
          liveRegion: true,
          label: _statusLabel(projection.uiState),
          child: AnimatedSwitcher(
            duration: reduceMotion ? Duration.zero : calls.motion.standard,
            child: Row(key: ValueKey(projection.uiState), children: [
              UiBox(
                width: 10,
                height: 10,
                background: projection.uiState == CallUiState.active
                    ? calls.colors.success
                    : terminal
                        ? calls.colors.danger
                        : calls.colors.textMuted,
                borderRadius: calls.radius.pillAll,
              ),
              SizedBox(width: calls.spacing.x2),
              Expanded(
                  child: UiText(
                _statusLabel(projection.uiState),
                variant: UiTextVariant.subheading,
              )),
              if (elapsedLabel case final label?)
                UiText(label,
                    variant: UiTextVariant.mono, tone: UiTextTone.muted),
            ]),
          ),
        ),
        SizedBox(height: calls.spacing.x3),
        Wrap(
            spacing: calls.spacing.x2,
            runSpacing: calls.spacing.x2,
            children: [
              if (projection.processingProfile ==
                  CallProcessingProfile.e2eePrivate)
                _Badge(
                    label: 'End-to-end encryption required',
                    color: calls.colors.textPrimary),
              if (recording)
                _Badge(label: 'Recording', color: calls.colors.danger),
              if (incompatibleRecording)
                _Badge(
                    label: 'Recording unavailable in encrypted calls',
                    color: calls.colors.danger),
              if (projection.qualityWarning case final warning?)
                _Badge(
                    label: _qualityWarningLabel(warning),
                    color: calls.colors.warning,
                    liveRegion: true),
              ..._processingLabels(projection).map((label) =>
                  _Badge(label: label, color: calls.colors.textMuted)),
            ]),
        if (participantsBuilder != null ||
            projection.joinedParticipantRefs.isNotEmpty) ...[
          SizedBox(height: calls.spacing.x3),
          participantsBuilder?.call(context, projection) ??
              _ParticipantStrip(projection: projection, calls: calls),
        ],
        if (captionsBuilder != null) ...[
          SizedBox(height: calls.spacing.x3),
          captionsBuilder!(context, projection),
        ],
        if (!terminal && projection.uiState != CallUiState.idle) ...[
          SizedBox(height: calls.spacing.x3),
          Wrap(
              spacing: calls.spacing.x2,
              runSpacing: calls.spacing.x2,
              children: _secondaryControls(recording)),
        ],
      ],
    );
    return UiCard(
      variant: UiCardVariant.muted,
      borderRadius: calls.radius.xlAll,
      padding: EdgeInsets.all(calls.spacing.x4),
      child: Padding(
        padding: EdgeInsets.zero,
        child: LayoutBuilder(builder: (context, constraints) {
          if (!constraints.hasBoundedHeight) {
            return Column(mainAxisSize: MainAxisSize.min, children: [
              content,
              if (primaryControls.isNotEmpty) ...[
                SizedBox(height: calls.spacing.x2),
                Wrap(
                    spacing: calls.spacing.x2,
                    runSpacing: calls.spacing.x2,
                    children: primaryControls),
              ],
            ]);
          }
          return Column(children: [
            Expanded(child: SingleChildScrollView(child: content)),
            if (primaryControls.isNotEmpty) ...[
              SizedBox(height: calls.spacing.x2),
              Wrap(
                  spacing: calls.spacing.x2,
                  runSpacing: calls.spacing.x2,
                  children: primaryControls),
            ],
          ]);
        }),
      ),
    );
  }

  List<Widget> _secondaryControls(bool recording) => [
        if (_interactive(projection.uiState) && onToggleMicrophone != null)
          _Control(
              label: 'Microphone',
              selected: microphoneMuted,
              onPressed: onToggleMicrophone),
        if (_interactive(projection.uiState) &&
            projection.mediaProfile != CallMediaProfile.audio &&
            onToggleCamera != null)
          _Control(
              label: 'Camera', selected: cameraOff, onPressed: onToggleCamera),
        if (projection.uiState == CallUiState.active &&
            projection.mediaProfile != CallMediaProfile.audio &&
            onToggleScreenShare != null)
          _Control(
              label: 'Share screen',
              selected: screenSharing,
              onPressed: onToggleScreenShare),
        if (_interactive(projection.uiState) &&
            projection.processingProfile == CallProcessingProfile.recordable &&
            onToggleCaptions != null)
          _Control(
              label: 'Captions',
              selected: captionsEnabled,
              onPressed: onToggleCaptions),
        if (_interactive(projection.uiState) &&
            projection.processingProfile == CallProcessingProfile.recordable &&
            onRequestRecording != null)
          _Control(
              label: 'Record',
              selected: recording,
              onPressed: onRequestRecording),
      ];

  List<Widget> _primaryControls() {
    switch (projection.uiState) {
      case CallUiState.incomingRinging:
        return [
          _Control(
              label: 'Accept', intent: UiIntent.primary, onPressed: onAccept),
          _Control(
              label: 'Decline', intent: UiIntent.danger, onPressed: onDecline),
        ];
      case CallUiState.outgoingRinging:
        return [
          _Control(
              label: 'Cancel call',
              intent: UiIntent.danger,
              onPressed: onCancel)
        ];
      case CallUiState.connecting:
      case CallUiState.active:
      case CallUiState.reconnecting:
        return [
          _Control(label: 'End call', intent: UiIntent.danger, onPressed: onEnd)
        ];
      default:
        return const [];
    }
  }
}

final class _Control extends StatelessWidget {
  const _Control(
      {required this.label,
      this.onPressed,
      this.selected = false,
      this.intent = UiIntent.neutral});
  final String label;
  final VoidCallback? onPressed;
  final bool selected;
  final UiIntent intent;

  @override
  Widget build(BuildContext context) => Semantics(
        button: true,
        selected: selected,
        label: label,
        excludeSemantics: true,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 48),
          child: UiButton(
            label: label,
            intent: selected ? UiIntent.secondary : intent,
            size: UiSize.lg,
            onPressed: onPressed,
          ),
        ),
      );
}

final class _Badge extends StatelessWidget {
  const _Badge(
      {required this.label, required this.color, this.liveRegion = false});
  final String label;
  final Color color;
  final bool liveRegion;
  @override
  Widget build(BuildContext context) => Semantics(
        liveRegion: liveRegion,
        label: label,
        child: UiBadge(label: label, color: color, outlined: true),
      );
}

final class _ParticipantStrip extends StatelessWidget {
  const _ParticipantStrip({required this.projection, required this.calls});

  final CallProjection projection;
  final UiThemeTokens calls;

  @override
  Widget build(BuildContext context) {
    final mediaByParticipant = {
      for (final media in projection.participantMediaStates)
        media.participantRef: media,
    };
    return Semantics(
      container: true,
      label: 'Participants',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final indexed in projection.joinedParticipantRefs.indexed)
            Padding(
              padding:
                  EdgeInsets.only(top: indexed.$1 == 0 ? 0 : calls.spacing.x2),
              child: _ParticipantRow(
                label: 'Participant ${indexed.$1 + 1}',
                media: mediaByParticipant[indexed.$2],
                calls: calls,
              ),
            ),
        ],
      ),
    );
  }
}

final class _ParticipantRow extends StatelessWidget {
  const _ParticipantRow(
      {required this.label, required this.media, required this.calls});

  final String label;
  final CallParticipantMediaState? media;
  final UiThemeTokens calls;

  @override
  Widget build(BuildContext context) {
    final states = <String>[
      if (media == null) 'Media state unavailable',
      if (media != null && !media!.audio) 'Microphone muted',
      if (media != null && !media!.video) 'Camera off',
      if (media?.screen ?? false) 'Sharing screen',
    ];
    return Semantics(
      label: [label, ...states].join(', '),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          UiText(label,
              variant: UiTextVariant.label, overflow: TextOverflow.ellipsis),
          if (states.isNotEmpty) ...[
            SizedBox(height: calls.spacing.x1),
            Wrap(
              spacing: calls.spacing.x2,
              runSpacing: calls.spacing.x1,
              children: states
                  .map((state) => UiText(state,
                      variant: UiTextVariant.bodySm, tone: UiTextTone.muted))
                  .toList(),
            ),
          ],
        ],
      ),
    );
  }
}

bool _terminal(CallUiState state) => const {
      CallUiState.ended,
      CallUiState.declined,
      CallUiState.cancelled,
      CallUiState.expired,
      CallUiState.failed,
    }.contains(state);

bool _interactive(CallUiState state) => const {
      CallUiState.connecting,
      CallUiState.active,
      CallUiState.reconnecting,
    }.contains(state);

List<String> _processingLabels(CallProjection projection) {
  if (projection.processingProfile == CallProcessingProfile.e2eePrivate) {
    return const [];
  }
  final labels = <String>[];
  switch (projection.recordingState) {
    case CallRecordingState.requested:
      labels.add('Recording requested');
    case CallRecordingState.finalizing:
      labels.add('Finalizing recording');
    case CallRecordingState.playable:
      labels.add('Recording ready');
    case CallRecordingState.failed:
      labels.add('Recording failed');
    case CallRecordingState.stopped:
      labels.add('Recording stopped');
    default:
      break;
  }
  switch (projection.captionsState) {
    case CallCaptionsState.starting:
      labels.add('Starting captions');
    case CallCaptionsState.active:
      labels.add('Captions live');
    case CallCaptionsState.stopping:
      labels.add('Stopping captions');
    case CallCaptionsState.stopped:
      labels.add('Captions stopped');
    case CallCaptionsState.failed:
      labels.add('Captions failed');
    default:
      break;
  }
  if (projection.transcriptState == CallIntelligenceState.pending) {
    labels.add('Transcript queued');
  } else if (projection.transcriptState == CallIntelligenceState.processing) {
    labels.add('Preparing transcript');
  } else if (projection.transcriptState == CallIntelligenceState.ready) {
    labels.add('Transcript ready');
  } else if (projection.transcriptState == CallIntelligenceState.failed) {
    labels.add('Transcript failed');
  }
  if (projection.summaryState == CallIntelligenceState.pending) {
    labels.add('Summary queued');
  } else if (projection.summaryState == CallIntelligenceState.processing) {
    labels.add('Preparing summary');
  } else if (projection.summaryState == CallIntelligenceState.ready) {
    labels.add('Summary ready');
  } else if (projection.summaryState == CallIntelligenceState.failed) {
    labels.add('Summary failed');
  }
  return labels;
}

String _qualityWarningLabel(CallQualityWarning warning) => switch (warning) {
      CallQualityWarning.networkDegraded => 'Network quality reduced',
      CallQualityWarning.mediaDegraded => 'Media quality reduced',
      CallQualityWarning.providerDegraded => 'Media service reconnecting',
    };

String _statusLabel(CallUiState state) => switch (state) {
      CallUiState.idle => 'No active call',
      CallUiState.incomingRinging => 'Incoming call',
      CallUiState.outgoingRinging => 'Calling',
      CallUiState.connecting => 'Checking call',
      CallUiState.active => 'Live',
      CallUiState.reconnecting => 'Rejoining media',
      CallUiState.ending => 'Ending call',
      CallUiState.ended => 'Call ended',
      CallUiState.declined => 'Call declined',
      CallUiState.cancelled => 'Call cancelled',
      CallUiState.expired => 'Call expired',
      CallUiState.failed => 'Call unavailable',
    };
