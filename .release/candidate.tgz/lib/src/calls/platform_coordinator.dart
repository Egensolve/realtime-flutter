
library;

import 'dart:async';

import 'package:egensolve_realtime/calls.dart';

abstract interface class CallControlPort {
  Future<void> fetchCanonicalSnapshot(String callId);
  Future<void> requestJoinCredential(String callId);
  Future<void> restoreCallSubscription(String callId);
}

abstract interface class CallRtcSessionPort {
  
  
  Future<void> connect(String callId);
  Future<void> stopLocalMedia();
  Future<void> discardCredential();
  Future<void> discardMediaKey();
}


abstract interface class CallOsSurfacePort {
  Future<void> reportIncomingCall(String callId);
  Future<void> updateCall(String callId, CallUiState state);
  Future<void> endCall(String? callId);
}



abstract interface class CallForegroundServicePort {
  Future<void> startForCall(String callId);
  Future<void> stop();
}

typedef CallProjectionListener = void Function(CallProjection projection);

final class FlutterCallCoordinator {
  FlutterCallCoordinator({
    required String installationRef,
    required CallControlPort control,
    required CallRtcSessionPort rtc,
    required CallOsSurfacePort osSurface,
    required CallForegroundServicePort foregroundService,
    CallProjectionListener? onProjection,
  })  : _projection = CallProjection(installationRef: installationRef),
        _control = control,
        _rtc = rtc,
        _osSurface = osSurface,
        _foregroundService = foregroundService,
        _onProjection = onProjection;

  final CallControlPort _control;
  final CallRtcSessionPort _rtc;
  final CallOsSurfacePort _osSurface;
  final CallForegroundServicePort _foregroundService;
  final CallProjectionListener? _onProjection;
  CallProjection _projection;
  bool _disposed = false;
  bool _cleanupSucceeded = false;
  Future<void>? _teardownFuture;
  String? _closingCallId;
  final _pendingEffects = <Future<void>>{};
  var _effectEpoch = _CallEffectEpoch(() async {});
  String? _osCallId;
  CallUiState? _osState;

  CallProjection get projection => _projection;

  Future<CallTransition> dispatch(CallInput input, DateTime now) async {
    if (_disposed) throw StateError('FlutterCallCoordinator is disposed.');
    final previous = _projection;
    final transition = reduceCall(previous, input, now);
    if (input.type == (const CallInput.accountLogout()).type) {
      await _terminate(transition.projection);
      return transition;
    }
    if (identical(previous, transition.projection) &&
        transition.effects.isEmpty) {
      return transition;
    }
    final next = transition.projection;
    final callChanged = previous.callId != next.callId;
    final cleanup = transition.effects
        .any((effect) => effect.type == CallEffectType.stopLocalMedia);
    if ((callChanged && previous.callId != null) ||
        (cleanup && previous.uiState != next.uiState)) {
      final pending = List<Future<void>>.of(_pendingEffects);
      final oldCallId = previous.callId;
      _effectEpoch = _CallEffectEpoch(() async {
        await Future.wait(pending);
        if (!_disposed) await _cleanupPorts(oldCallId);
      });
    }
    final epoch = _effectEpoch;
    final settled = Completer<void>();
    _pendingEffects.add(settled.future);
    _projection = transition.projection;
    try {
      if (cleanup) {
        
        
        try {
          _onProjection?.call(_projection);
        } finally {
          await _cleanupPorts(next.callId ?? previous.callId);
        }
      } else {
        _onProjection?.call(_projection);
        if (callChanged ||
            _needsOsSync(next) ||
            transition.effects.isNotEmpty) {
          await epoch.ready();
          if (_isCurrent(epoch)) await _syncOsProjection(next, epoch);
          for (final effect in transition.effects) {
            if (!_isCurrent(epoch)) break;
            await _runEffect(effect, previous.callId);
          }
        }
      }
    } finally {
      try {
        
        if (!_isCurrent(epoch)) {
          await _cleanupPorts(next.callId ?? previous.callId);
        }
      } finally {
        _pendingEffects.remove(settled.future);
        settled.complete();
      }
    }
    return !_isCurrent(epoch) ? CallTransition(_projection) : transition;
  }

  bool _isCurrent(_CallEffectEpoch epoch) =>
      !_disposed && identical(epoch, _effectEpoch);

  
  Future<CallTransition> handleInvitation({
    required String callId,
    required DateTime expiresAt,
    required DateTime now,
    bool outgoing = false,
  }) =>
      dispatch(
        CallInput.invitation(
            callId: callId, expiresAt: expiresAt, outgoing: outgoing),
        now,
      );

  Future<void> endAuthenticatedSession(DateTime now) => _terminate(
      reduceCall(_projection, const CallInput.accountLogout(), now).projection);

  Future<void> dispose() => endAuthenticatedSession(DateTime.now());

  Future<void> _terminate(CallProjection cleared) {
    final existing = _teardownFuture;
    if (existing != null) return existing;
    if (_disposed && _cleanupSucceeded) return Future<void>.value();
    final notify = !_disposed;
    _closingCallId ??= _projection.callId;
    
    _disposed = true;
    _projection = cleared;
    final completion = Completer<void>();
    _teardownFuture = completion.future;
    unawaited(_finishTeardown(completion, notify));
    return completion.future;
  }

  Future<void> _finishTeardown(Completer<void> completion, bool notify) async {
    var failed = false;
    if (notify) {
      try {
        _onProjection?.call(_projection);
      } catch (_) {
        failed = true;
      }
    }
    try {
      await _cleanupPorts(_closingCallId);
    } catch (_) {
      failed = true;
    }
    _teardownFuture = null;
    if (failed) {
      completion.completeError(StateError('Calls session cleanup failed.'));
    } else {
      completion.complete();
    }
  }

  Future<void> _cleanupPorts(String? callId) async {
    _cleanupSucceeded = false;
    var failed = false;
    for (final cleanup in <Future<void> Function()>[
      _rtc.stopLocalMedia,
      _rtc.discardCredential,
      _rtc.discardMediaKey,
      _foregroundService.stop,
      () => _endOsCall(callId),
    ]) {
      try {
        await cleanup();
      } catch (_) {
        failed = true;
      }
    }
    if (failed) throw StateError('Calls session cleanup failed.');
    _cleanupSucceeded = true;
  }

  bool _needsOsSync(CallProjection next) =>
      next.callId != null &&
      {
        CallUiState.incomingRinging,
        CallUiState.outgoingRinging,
        CallUiState.connecting,
        CallUiState.active,
        CallUiState.reconnecting
      }.contains(next.uiState) &&
      (_osCallId != next.callId || _osState != next.uiState);

  Future<void> _endOsCall(String? callId) async {
    await _osSurface.endCall(callId);
    if (callId == null || callId == _osCallId) {
      _osCallId = null;
      _osState = null;
    }
  }

  Future<void> _syncOsProjection(
      CallProjection next, _CallEffectEpoch epoch) async {
    final callId = next.callId;
    if (callId == null || !_needsOsSync(next)) return;
    if (next.uiState == CallUiState.incomingRinging) {
      await _osSurface.reportIncomingCall(callId);
    } else {
      await _osSurface.updateCall(callId, next.uiState);
      if (_isCurrent(epoch) && next.uiState == CallUiState.active) {
        await _foregroundService.startForCall(callId);
      }
    }
    if (_isCurrent(epoch)) {
      _osCallId = callId;
      _osState = next.uiState;
    }
  }

  Future<void> _runEffect(CallEffect effect, String? previousCallId) async {
    switch (effect.type) {
      case CallEffectType.fetchSnapshot:
        await _control.fetchCanonicalSnapshot(effect.callId!);
      case CallEffectType.requestJoinCredential:
        await _control.requestJoinCredential(effect.callId!);
      case CallEffectType.connectRtc:
        await _rtc.connect(effect.callId!);
      case CallEffectType.restoreCallSubscription:
        await _control.restoreCallSubscription(effect.callId!);
      case CallEffectType.stopLocalMedia:
        await _rtc.stopLocalMedia();
        await _foregroundService.stop();
      case CallEffectType.discardCredential:
        await _rtc.discardCredential();
      case CallEffectType.discardMediaKey:
        await _rtc.discardMediaKey();
      case CallEffectType.endOsCall:
        await _foregroundService.stop();
        await _endOsCall(effect.callId ?? _projection.callId ?? previousCallId);
      case CallEffectType.clearInvitationDedupe:
        
        break;
    }
  }
}



final class _CallEffectEpoch {
  _CallEffectEpoch(this._prepare);
  final Future<void> Function() _prepare;
  Future<void>? _preparation;

  Future<void> ready() =>
      _preparation ??= _prepare().catchError((Object error, StackTrace stack) {
        _preparation = null;
        Error.throwWithStackTrace(error, stack);
      });
}
